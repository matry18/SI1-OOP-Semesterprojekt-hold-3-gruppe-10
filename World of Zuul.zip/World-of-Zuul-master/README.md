The World of Zuul assignment from BlueJ. The Sherlock Holmes story, brought
to you by [Rico de Feijter](http://nl.linkedin.com/pub/rico-de-feijter/2b/287/1b7) en [Marcellino van Hecke](http://nl.linkedin.com/in/marcellinovanhecke).
